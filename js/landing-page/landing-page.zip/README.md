# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

This page and code represents the second project on udacity's frontend dev.

author:Alexander Khaniha
date: 22.02.20