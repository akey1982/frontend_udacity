import {
  handleSubmit,
} from "./formHandler";

test("It should return true",  () => {
  expect(handleSubmit).toBeDefined();
});

test("It should be a function", () => {
  expect(typeof handleSubmit).toBe("function");
});