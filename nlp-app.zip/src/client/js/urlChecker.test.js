import {
    urlChecker
} from './urlChecker';

test('Is a valid url', () => {
    expect(urlChecker('https://www.apple.com')).toBeTruthy()
})




test('Is not a valid url', () => {
    expect(urlChecker('test')).toBeFalsy()
})