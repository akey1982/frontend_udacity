# weather-journal-app

## Table of Contents

* [Instructions](#instructions)

## Instructions

This page and code represents the thrid project on udacity's frontend dev, start the express server and enjoy.

@reviewer take care on you !  

author: Alexander Khaniha
date: 19.03.20